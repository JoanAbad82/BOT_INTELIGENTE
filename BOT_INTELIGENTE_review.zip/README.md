# BOT_INTELIGENTE

Proyecto de bot de trading (XRP/USDC, 15m) con CCXT, pandas y Loguru.
