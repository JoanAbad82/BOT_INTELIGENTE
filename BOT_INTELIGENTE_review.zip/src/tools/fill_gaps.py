# ==========================================
# ========== FILE: src/tools/fill_gaps.py
# ==========================================
from __future__ import annotations

from pathlib import Path
from datetime import timezone
from typing import List, Tuple

import pandas as pd
from loguru import logger

from src.data.ohlcv_downloader import FetchConfig, download_ohlcv
from src.utils.logging import setup_logging

# ⚠️ OJO: Pandas != CCXT
FREQ_PANDAS = "15min"  # ✅ sin FutureWarnings (antes "15T")
TF_CCXT = "15m"        # CCXT usa sufijo 'm'


def _ensure_utc_index(df: pd.DataFrame) -> pd.DataFrame:
    """
    Asegura que el índice datetime:
      - es DatetimeIndex
      - está en UTC (tz-aware)
      - está ordenado ascendente y sin duplicados
    """
    if not isinstance(df.index, pd.DatetimeIndex):
        df.index = pd.to_datetime(df.index, utc=True, errors="coerce")

    # Si viene naive, localizamos a UTC; si viene con tz, convertimos a UTC.
    if df.index.tz is None:
        df.index = df.index.tz_localize("UTC")
    else:
        df.index = df.index.tz_convert("UTC")

    # Orden + deduplicado conservando la última ocurrencia
    df = df[~df.index.duplicated(keep="last")].sort_index()
    return df


def group_gaps(gaps: pd.DatetimeIndex, freq: str) -> List[Tuple[pd.Timestamp, pd.Timestamp]]:
    """Agrupa huecos contiguos en rangos [start, end] según el paso `freq`."""
    if len(gaps) == 0:
        return []

    ranges: List[Tuple[pd.Timestamp, pd.Timestamp]] = []
    start = gaps[0]
    prev = gaps[0]
    step = pd.Timedelta(freq)  # '15min'

    for ts in gaps[1:]:
        if ts - prev == step:
            prev = ts
            continue
        ranges.append((start, prev))
        start = ts
        prev = ts

    ranges.append((start, prev))
    return ranges


def main() -> None:
    setup_logging("BOT_INTELIGENTE")

    # Ajusta aquí si el nombre de tu CSV cambia
    src_csv = Path("data/ohlcv/XRPUSDC_15m_2025-07-15_2025-09-18.csv")
    if not src_csv.exists():
        logger.error(f"No existe el archivo de origen: {src_csv}")
        return

    # Carga robusta y normalización del índice a UTC
    df = pd.read_csv(src_csv, parse_dates=["datetime"], index_col="datetime")
    df = _ensure_utc_index(df)

    # === Validaciones de entrada (contrato de columnas y tz) ===
    expected_cols = {"open", "high", "low", "close", "volume"}
    missing = expected_cols.difference(set(df.columns))
    if missing:
        logger.error(f"Columnas faltantes en origen: {sorted(missing)}")
        return
    if df.index.tz is None or str(df.index.tz) != "UTC":
        logger.error("El índice no está en UTC tras la normalización.")
        return

    # Construye el rango completo esperado a 15 min (Pandas)
    full = pd.date_range(df.index.min(), df.index.max(), freq=FREQ_PANDAS, tz="UTC")
    gaps = full.difference(df.index)

    logger.info(f"Huecos detectados: {len(gaps)}")
    if len(gaps) == 0:
        logger.info("Nada que rellenar.")
        # Aun así, exportamos una versión canónica/ordenada por consistencia
        out_same = src_csv.with_name(src_csv.stem + "_filled.csv")
        out_same.parent.mkdir(parents=True, exist_ok=True)
        # Fuerza tipado consistente
        numeric_cols = ["open", "high", "low", "close", "volume"]
        df[numeric_cols] = df[numeric_cols].apply(pd.to_numeric, errors="coerce").astype("float64")
        df.to_csv(out_same, index=True)
        logger.info(f"Guardado dataset (sin cambios) en: {out_same}")
        return

    ranges = group_gaps(gaps, FREQ_PANDAS)
    logger.info(f"Tramos contiguos: {len(ranges)}")

    filled_parts = []
    margin = pd.Timedelta("75min")  # ✅ sin FutureWarnings (antes "75T")

    for i, (g_start, g_end) in enumerate(ranges, 1):
        # Añadimos margen para evitar bordes incompletos en fetch
        since = (g_start - margin).to_pydatetime().replace(tzinfo=timezone.utc)
        until = (g_end + margin).to_pydatetime().replace(tzinfo=timezone.utc)
        logger.info(f"[{i}/{len(ranges)}] Rellenando {g_start} → {g_end} (con margen)")

        cfg = FetchConfig(symbol="XRP/USDC", timeframe=TF_CCXT, since=since, until=until)
        part_path = download_ohlcv(cfg)
        part = pd.read_csv(part_path, parse_dates=["datetime"], index_col="datetime")
        part = _ensure_utc_index(part)

        # Validación rápida de columnas en cada parche
        miss_part = expected_cols.difference(set(part.columns))
        if miss_part:
            logger.warning(f"Parche con columnas faltantes {sorted(miss_part)} en {part_path}; se omite.")
            continue

        filled_parts.append(part)

    if not filled_parts:
        logger.warning("No se generaron parches válidos. No hay cambios que aplicar.")
        out_same = src_csv.with_name(src_csv.stem + "_filled.csv")
        out_same.parent.mkdir(parents=True, exist_ok=True)
        df.to_csv(out_same, index=True)
        logger.info(f"Guardado dataset (original) en: {out_same}")
        return

    # Fusiona, desduplica y ordena
    patch = pd.concat([df] + filled_parts, axis=0)
    patch = _ensure_utc_index(patch)

    # Fuerza tipado float64 en columnas numéricas
    numeric_cols = ["open", "high", "low", "close", "volume"]
    patch[numeric_cols] = patch[numeric_cols].apply(pd.to_numeric, errors="coerce").astype("float64")

    # Re-chequeo de huecos sobre el nuevo rango completo
    new_full = pd.date_range(patch.index.min(), patch.index.max(), freq=FREQ_PANDAS, tz="UTC")
    remaining = new_full.difference(patch.index)
    logger.info(f"Huecos restantes tras parcheo: {len(remaining)}")
    if len(remaining) > 0:
        logger.warning(
            f"Persisten {len(remaining)} huecos tras el parcheo. Considera reintentar o ampliar margen."
        )

    out = src_csv.with_name(src_csv.stem + "_filled.csv")
    out.parent.mkdir(parents=True, exist_ok=True)
    patch.to_csv(out, index=True)
    logger.info(f"Guardado dataset rellenado: {out}")


if __name__ == "__main__":
    main()
