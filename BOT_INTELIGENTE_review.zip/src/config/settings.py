# ==================================
# ========== FILE: src/config/settings.py
# ==================================
from __future__ import annotations

import os
from dataclasses import dataclass
from dotenv import load_dotenv

# Carga el .env en la raíz del proyecto
load_dotenv()


@dataclass
class Settings:
    """
    Configuración del proyecto BOT_INTELIGENTE.
    Regla clave: el símbolo por defecto DEBE cotizar en USDC.
    """
    # Claves de API (testnet)
    binance_testnet_api_key: str = os.getenv("BINANCE_TESTNET_API_KEY", "")
    binance_testnet_api_secret: str = os.getenv("BINANCE_TESTNET_API_SECRET", "")

    # Símbolo por defecto (en este proyecto SIEMPRE cotizamos en USDC)
    default_symbol: str = os.getenv("DEFAULT_SYMBOL", "XRP/USDC").strip().upper()

    # Opciones de conexión
    enable_rate_limit: bool = os.getenv("ENABLE_RATE_LIMIT", "true").strip().lower() == "true"
    timeout_ms: int = int(os.getenv("TIMEOUT_MS", "20000"))
    sandbox_mode: bool = os.getenv("SANDBOX_MODE", "true").strip().lower() == "true"

    def __post_init__(self) -> None:
        """
        Fuerza que el símbolo por defecto use USDC como quote.
        Evita errores de entorno (p. ej., poner USDT por accidente).
        """
        if not self.default_symbol.endswith("/USDC"):
            raise ValueError(
                f"default_symbol debe cotizar en USDC (recibido: {self.default_symbol})"
            )


settings = Settings()
